#ifndef toc_print_ast
#define toc_print_ast
#include "ast.h"

void printAST(ASTNode *ast);

#endif
# TOC Assignment 2: Simple C interpreter

Grammar is in the PDF file.
To compile, run `make`.
To run, enter your program in `input.txt` and run `./bin/main`.
